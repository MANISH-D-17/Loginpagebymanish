from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = "your_secret_key"

# Mock database for simplicity (use a real database in production)
users = {}

# Route for home page with login/register options
@app.route("/")
def home():
    return render_template("home.html")

# Route for login
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if username in users and users[username] == password:
            session["username"] = username
            return redirect(url_for("profile"))
        else:
            return "Invalid username or password. Try again!"
    return render_template("login.html")

# Route for registration
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if username in users:
            return "Username already exists!"
        else:
            users[username] = password
            return redirect(url_for("login"))
    return render_template("register.html")

# Route for profile page
@app.route("/profile")
def profile():
    if "username" in session:
        return render_template("profile.html", session=session)
    return redirect(url_for("login"))

# Route to log out
@app.route("/logout")
def logout():
    session.pop("username", None)
    return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True)
